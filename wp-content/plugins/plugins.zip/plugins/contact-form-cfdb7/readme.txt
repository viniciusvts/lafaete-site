=== Contact Form 7 Database Addon - CFDB7 ===
Contributors: arshidkv12
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=H5F3Z6S3MNTXA&lc=IN&item_name=wp%2dlogin%2dlimit&amount=5%2e00&currency_code=USD&button_subtype=services&bn=PP%2dBuyNowBF%3abtn_buynowCC_LG%2egif%3aNonHosted
Tags: cf7, contact form 7, contact form 7 db, contact form db, contact form seven, contact form storage, export contact form, save contact form, wpcf7
Requires at least: 3.5
Tested up to: 4.9.6
Stable tag: 1.2.3
License: GPLv2

Save and manage Contact Form 7 messages. Never lose important data. It is lightweight contact form 7 db plugin


== Description ==

The "CFDB7" plugin saves contact form 7 submissions to your WordPress database. Export the data to a csv file.
By simply installing the plugin, it will automatically begin to capture form submissions from contact form 7.

= Features of CFDB 7 =

* No configuration is needed
* Single database table for all forms
* Easy to use ang lightweight plugin
* Developer friendly & easy to customize
* No configuration is needed

Support : [http://www.ciphercoin.com/contact/](http://www.ciphercoin.com/contact/)
Extensions : [Contact form 7 more Add-ons](https://ciphercoin.com/contact-form-7-database-cfdb7-add-ons/)

== Installation ==

1. Download and extract plugin files to a wp-content/plugin directory.
2. Activate the plugin through the WordPress admin interface.
3. Done !


== Screenshots ==
1. Admin

== Changelog ==
= 1.0.0 =

First version of plugin.
= 1.1.6 =
Fixed minor bugs
Add action hooks
= 1.1.7 =
Add filter hooks
Multisite support

= 1.1.9 =
Fixed Sorting bugs

== 1.2 ==
Fixed csv export bug

== 1.2.1 ==
Multisite network bug fixed 

== 1.2.2 ==
Added cfdb7_access capability

== 1.2.3 ==
Fixed csv export issue 
