<?php
if ( ! class_exists('\\SendGrid\\Client') ) {
	require 'vendor/autoload.php';	
}
?>