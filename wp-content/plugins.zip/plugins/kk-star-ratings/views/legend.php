<div class="kksr-legend" style="<?php echo $count ? '' : 'display: none; ' ?>line-height:<?php echo $size; ?>px;font-size:<?php echo $size/1.5; ?>px">
    <div class="kksr-legend-score"><?php echo apply_filters('kksr_score', $score); ?></div>
    <div class="kksr-legend-meta"><?php echo apply_filters('kksr_count', $count); ?></div>
</div>
