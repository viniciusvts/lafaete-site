<input type="<?php echo isset($type) ? $type : 'text' ?>"
    id="<?php echo $id; ?>"
    name="<?php echo $name; ?>"
    value="<?php echo $value; ?>"
    style="min-width: 160px; min-height: 28px;">
