<?php

// You can create tab specific files in this directory to override the default tab view.

http_response_code(404);

die();
