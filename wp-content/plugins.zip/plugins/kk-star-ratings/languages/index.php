<?php

http_response_code(404);

die();
