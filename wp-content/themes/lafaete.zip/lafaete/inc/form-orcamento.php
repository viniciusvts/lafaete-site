<div class="fale-conosco" id="faca-um-orcamento">
    <div class="container-fluid">
    <div class="cabecalho">
        <h2>Faça um orçamento</h2>
        <span></span> 
    </div>
    <?php echo do_shortcode('[contact-form-7 id="182" html_id="facaUmOrcamento" title="Orçamento"]'); ?>
    </div>
</div>